using System;

namespace Designator.Domain.Repository;

public interface IDesignationRepository
{

}
